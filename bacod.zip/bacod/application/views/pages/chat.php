<?php
if(isset($this->session->username)) {
	$_POST['name']=$this->session->username;
}
else {
	$_POST['name']='Anonymous';
}
if(isset($_POST['action'])) {
	$data = array(
		'name' => $_POST['name'],
		'message' => gzdeflate($_POST['message'])
	);
$this->db->insert('table_message', $data);unset($data);}?>

<body class="modal-body">
	<div class="modal-header">
		<div class="table-responsive">
			<table class="table table-striped table-hover">
				<thead>
					<tr>
						<th>Username</th>
						<th>Message</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($this->bacod_model->get_message() as $row):?>
					<tr>
						<td><?=htmlentities($row->name);?></td>
						<td><?=htmlentities(gzinflate($row->message));?></td>
					</tr>
					<?php endforeach;?>
				</tbody>
			</table>
		</div>
	</div>
	<?=form_open('',array('method'=>'post','class'=>'modal-footer'));?>
	<?=$form['message'];?>
	<?=$form['button'];?>
	<?=form_close();?>
</body>