<?php
if(isset($_POST['action'])) {
	if($this->db->query("SELECT name, password FROM table_user WHERE name=$_POST[username] && password=sha1($_POST[password])")) {
		$this->session->username=$_POST['username'];
		header('Location: chat');	
	}
}
?>
<body class="modal-body">
	<div class="modal-title" align="center">
		<h1>Sigin your account</h1>
	</div>
	<div class="modal-content" align="center">
		<?=form_open('',array('method'=>'post'));?>
		<?=$form['username'];?>
		<?=$form['password'];?>
		<?=$form['button'];?>
		<?=form_close();?>
	</div>
</body>
