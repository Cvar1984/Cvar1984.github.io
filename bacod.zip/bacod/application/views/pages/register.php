<?php
if(isset($_POST['action'])) {
	$data = array(
		'name' => $_POST['username'],
		'email' => $_POST['email'],
		'password' => $_POST['password'],
		'bio' => FALSE
	);
if($this->db->insert('table_user', $data)) {
	header('Location: login');

}
else {
	alert('Failed');
}
unset($data);}?>
<body class="modal-body">
	<div class="modal-title" align="center">
		<h1>Register your account</h1>
	</div>
	<div class="modal-content" align="center">
		<?=form_open('',array('method'=>'post'));?>
		<?=$form['username'];?>
		<?=$form['email'];?>
		<?=$form['password'];?>
		<?=$form['button'];?>
		<?=form_close();?>
	</div>
</body>
